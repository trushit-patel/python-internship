def myfunction():
    print('hello this is my fucniton of demo file')

def myfunction2(name):
    print('hello this is my fucniton of demo file')
    return name*2